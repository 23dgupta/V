package com.flightapp.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.flightapp.model.Airline;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class AirlineTestRepository {

	@Autowired
	AirlineRepository airlineRepository;
	
	@Test
	@Order(1)
	public void createAirline() {
		Airline a = new Airline(177L,"Chennai","Hyderabad","Indigo","inddddd","veg","IND586",new Date(),new Date(),3455L,false);
		airlineRepository.save(a);
		System.out.println(a.getFlight_number());
		System.out.println("vinay");
		Boolean actualResult = airlineRepository.isPersonExitsById(177L);
		
		assertThat(actualResult).isTrue();

	
	}
	

	@Test
	@Order(2)
	public void testReadAll() {
		List list = airlineRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	
	@Test
	@Order(3)
	public void testRead () {
		Airline airline = airlineRepository.findById(177L).get();
		System.out.println(airline.getAirline_name());
		assertEquals("Indigo", airline.getAirline_name());
	}
	@Test
	@Order(4)
	public void blockAirline() {
		int a = airlineRepository.updateAirline(177, true);
		Airline airline = airlineRepository.findById(177L).get();
		assertEquals(true, airline.isBlock());
	}
	@Test
	@Order(5)
	public void testDelete () {
		airlineRepository.deleteById(167L);
		assertThat(airlineRepository.existsById(177L)).isFalse();
	}
}
