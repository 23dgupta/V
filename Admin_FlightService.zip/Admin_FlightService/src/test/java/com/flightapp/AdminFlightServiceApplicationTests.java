package com.flightapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminFlightServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
