package com.flightapp.service;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.flightapp.repository.AirlineRepository;
import com.flightapp.servcie.AirlineService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class AirlineServiceTest {

	
	@Mock
	private AirlineRepository airlineRepository;
	
	private AirlineService airlineService;
	
	@Test
	void getAllAirlines() {
		airlineService.get();
		verify(airlineRepository).findAll();
	}
	
	@Test
	void blockAirline() {
		airlineService.blockAirline(167L, true);
		verify(airlineRepository).updateAirline(167L, true);
	}
}
