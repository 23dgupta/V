package com.flightapp.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name="airlines")
@Table(name="airlines")
@Component

public class Airline {

	public Airline() {
		super();
	}
	public Airline(Long id, String origin, String destination, String airline_name, String logo, String meal,
			String flight_number, Date start_time, Date end_time, Long price, boolean block) {
		super();
		this.id = id;
		this.origin = origin;
		this.destination = destination;
		this.airline_name = airline_name;
		this.logo = logo;
		this.meal = meal;
		this.flight_number = flight_number;
		this.start_time = start_time;
		this.end_time = end_time;
		this.price = price;
		this.block = block;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private Long id;
	@Column
	private String origin;
	@Column
	private String destination;
	@Column
	private String airline_name;
	@Column
	private String logo;
	@Column
	private String meal;
	public String getAirline_name() {
		return airline_name;
	}
	public void setAirline_name(String airline_name) {
		this.airline_name = airline_name;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public String getFlight_number() {
		return flight_number;
	}
	public void setFlight_number(String flight_number) {
		this.flight_number = flight_number;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	@Column
	private String flight_number;
	@Column
	@Temporal(TemporalType.TIMESTAMP)
	private Date start_time;
	@Column
	@Temporal(TemporalType.TIMESTAMP)
	private Date end_time;
	@Column
	private Long price;
	@Column
	private boolean block;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}


	public Date getStart_time() {
		return start_time;
	}
	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}
	public Date getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public boolean isBlock() {
		return block;
	}
	public void setBlock(boolean block) {
		this.block = block;
	}
	
	
}
