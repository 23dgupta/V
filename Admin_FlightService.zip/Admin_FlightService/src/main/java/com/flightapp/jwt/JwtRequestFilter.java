package com.flightapp.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.flightapp.servcie.AdminDetailService;

import io.jsonwebtoken.ExpiredJwtException;
@Component
public class JwtRequestFilter extends OncePerRequestFilter {
	
	@Autowired
	private AdminDetailService adminDetailService;
	
	@Autowired
     private JwtTokenUtil jwtTokenUtil;

//    @Value("${jwt.http.request.header}")
//    private String tokenHeader;
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		System.out.println("Step 4");
		  response.setHeader("Access-Control-Allow-Origin", "*");
	        response.setHeader("Access-Control-Expose-Headers", "*");
	        response.setHeader("Access-Control-Allow-Methods", "PUT,GET,POST,PATCH,DELETE,OPTIONS");
	        response.setHeader("Access-Control-Allow-Headers", "*");
		final String requestTokenHeader = request.getHeader("Authorization");
		System.out.println(request.getHeaderNames() + "Content");
		String username = null;
		String jwtToken = null;
		
		if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
			jwtToken = requestTokenHeader.substring(7);
//             System.out.println(requestTokenHeader + "step 5");
			try {
				username = jwtTokenUtil.getUsernameFromToken(jwtToken);
				System.out.println(username + "ewe");
			} catch (IllegalArgumentException e) {
				System.out.println("Unable to get JWT Token");
			} catch (ExpiredJwtException e) {
				System.out.println("JWT Token has expired");
			}
		} else {
			 logger.error("Cannot set user authentication: {}");
		}
		
		//Once we get the token validate it.
		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

			UserDetails userDetails = this.adminDetailService.loadUserByUsername(username);

			// if token is valid configure Spring Security to manually set authentication
			if (jwtTokenUtil.validateToken(jwtToken, userDetails)) {

				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				usernamePasswordAuthenticationToken
						.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				// After setting the Authentication in the context, we specify
				// that the current user is authenticated. So it passes the Spring Security Configurations successfully.
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			}
		}
		filterChain.doFilter(request, response);

	}

}
