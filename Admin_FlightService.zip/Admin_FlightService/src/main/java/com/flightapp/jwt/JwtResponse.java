package com.flightapp.jwt;

import java.io.Serializable;

public class JwtResponse implements Serializable {
	
	private static final long serialVersionUID = -8091879091924046844L;
	
	private final String jwttoken;
	private final boolean success;
	
	public JwtResponse(String jwttoken, boolean success) {
		this.jwttoken = jwttoken;
		this.success = success;
	}

	public String getToken() {
		return this.jwttoken;
	}
	
	public boolean getSuccess() {
		return this.success;
	}

}
