package com.flightapp.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.model.Airline;
import com.flightapp.repository.AirlineRepository;
import com.flightapp.servcie.AirlineService;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/v1.0/flight")
public class AirlineController {
	

	@Autowired
	private AirlineService airlineService;
	
	@Autowired
	private AirlineRepository airlineRepository;
	@PostMapping("/airline/register")
	public ResponseEntity<Airline> addAirline(@Validated @RequestBody Airline airline) {
		try {
			System.out.println(airline.getAirline_name());
			return new ResponseEntity<Airline>(airlineService.add(airline), HttpStatus.CREATED);
			
		} catch (Exception e) {
			return new ResponseEntity<Airline>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/airlines")
	public ResponseEntity<List<Airline>> getAllAirlines() {
		try {
			List<Airline> list = airlineService.get();
			
			if (list.isEmpty() || list.size() == 0) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			
			return new ResponseEntity<List<Airline>>(list, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PutMapping("airlines/{id}")
	public ResponseEntity<String> blockFlight(@PathVariable("id") long id, @RequestParam boolean block){
		System.out.println(block);
		System.out.println("vinay1");
		return new ResponseEntity<String>(airlineService.blockAirline(id, block)+" record(s) updated.", HttpStatus.CREATED);
	}
	@GetMapping("/searchFlight")
	public ResponseEntity<List> searchAirline(@RequestParam String origin, @RequestParam String destination,
			@DateTimeFormat(pattern = "yyyy-MM-dd") Date journeyDate){
		System.out.println(journeyDate);
	return new ResponseEntity<List>(airlineRepository.searchFlight(origin, destination, journeyDate),HttpStatus.OK);
		
	}
}
