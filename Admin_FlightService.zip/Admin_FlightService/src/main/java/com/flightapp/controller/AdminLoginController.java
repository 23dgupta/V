package com.flightapp.controller;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.jwt.JwtResponse;
import com.flightapp.jwt.JwtTokenUtil;
import com.flightapp.payload.AdminLoginRequest;
import com.flightapp.servcie.AdminDetailService;
import com.flightapp.servcie.MapValidationErrorService;
//import com.jwt.config.JwtTokenUtil;
//import com.jwt.model.JwtResponse;

@RestController
@CrossOrigin(origins = {"http://localhost:3000"})
@RequestMapping("/api/v1.0/flight")

public class AdminLoginController {

	@Autowired
	private MapValidationErrorService mapValidationErrorService;
	
	@Autowired
	private AdminDetailService adminDetailService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	
	  @PostMapping("/admin/login")
	    public ResponseEntity<?> authenticateUser( @RequestBody AdminLoginRequest loginRequest, BindingResult result) throws Exception{
		  System.out.println(loginRequest.getUsername());
		  ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
		  if(errorMap != null) return errorMap;

			authenticate(loginRequest.getUsername(), loginRequest.getPassword());
			final UserDetails userDetails = adminDetailService.loadUserByUsername(loginRequest.getUsername());
			System.out.println(userDetails.getUsername());
			
			final String token = jwtTokenUtil.generateToken(userDetails);
			return ResponseEntity.ok(new JwtResponse(token,true));
	  }
		private void authenticate(String username, String password) throws Exception {
			System.out.println(username + ""+password);
			System.out.println(authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password)));
			try {
				authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
			} catch (DisabledException e) {
				throw new Exception("USER_DISABLED", e);
			} catch (BadCredentialsException e) {
				throw new Exception("INVALID_CREDENTIALS", e);
			}
		}
		
		@GetMapping("/welcome")
		public String welcome() {
			return "Authorized";
		}
	  }

