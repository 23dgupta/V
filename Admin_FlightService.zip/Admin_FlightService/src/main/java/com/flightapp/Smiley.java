package com.flightapp;

public class Smiley extends Thread { public void run() { 


 while(true) { 

 try { 

 System.out.print(":"); 

 sleep(100); 

 System.out.print("-"); 
 sleep(100); 

 System.out.println(")"); 

 sleep(100);

 } catch (InterruptedException e) { e.printStackTrace(); } } } public static void main(String[] args) { new Smiley().start(); new Smiley().start(); } }

