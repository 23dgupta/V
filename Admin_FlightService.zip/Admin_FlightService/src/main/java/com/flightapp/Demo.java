package com.flightapp;

class MyNumber {
	// The number that should be printed:
	int n = 55;
	}
	class MySuperclass {
	MyNumber num = new MyNumber();
	}
	public class Demo extends MySuperclass {
	public static void main(String[] args) {
	Demo obj = new Demo();
	obj.print();
	}
	public void print() {
	System.out.println( /* (1) INSERT THE SIMPLEST EXPRESSION HERE */ );
	}
	}