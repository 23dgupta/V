package com.flightapp.repository;

import java.util.*;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.flightapp.model.Airline;

import java.sql.*;
@Component
@Repository
public interface AirlineRepository extends JpaRepository<Airline, Long> {

	@Transactional
	@Modifying
	@Query("UPDATE airlines SET block = :block WHERE id = :id")
	int updateAirline(long id, boolean block);
	@Transactional
	@Modifying
	@Query("FROM airlines WHERE origin =:origin and destination =:destination and cast(start_time as date) =:start_time")
	List<Airline> searchFlight(String origin, String destination,  Date start_time);
	
	@Query("SELECT CASE WHEN COUNT(s) > 0 THEN TRUE ELSE FALSE END FROM airlines s WHERE s.id = :id")
	Boolean isPersonExitsById(Long id);
}
