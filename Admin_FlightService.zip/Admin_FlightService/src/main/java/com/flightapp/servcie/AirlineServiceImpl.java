package com.flightapp.servcie;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.model.Airline;
import com.flightapp.repository.AirlineRepository;


@Service
public class AirlineServiceImpl implements AirlineService {

	@Autowired
	private AirlineRepository airlineRepository;
	
	@Override
	public Airline add(Airline airline) {
		// TODO Auto-generated method stub
		System.out.println(airline.getDestination());
		  return airlineRepository.save(airline);
	}

	@Override
	public List get() {
		// TODO Auto-generated method stub
		return airlineRepository.findAll();
	}

	@Override
	public int blockAirline(long id, boolean block) {
		// TODO Auto-generated method stub
		return airlineRepository.updateAirline(id, block);
	}

	

}
