package com.flightapp.servcie;

public class Smiley extends Thread {
public void run() { // (1)
while(true) { // (2)
try { // (3)
System.out.print(":"); // (4)
sleep(100); // (5)
System.out.print("-"); // (6)
sleep(100); // (7)
System.out.println(")"); // (8)
sleep(100); // (9)
} catch (InterruptedException e) {
e.printStackTrace();
}
}
}
public static void main(String[] args) {
new Smiley().start();
new Smiley().start();
}
}