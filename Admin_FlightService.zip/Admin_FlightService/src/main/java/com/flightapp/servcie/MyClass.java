package com.flightapp.servcie;



class MySuperclass {
public Integer step1(int i) { return 1; } 
protected String step2(String str1, String str2) { return str1; } 
public String step2(String str1) { return str1; } 
public static String step2() { return "Hi"; } 
public MyClass makeIt() { return new MyClass(); } 
public MySuperclass makeIt2() { return new MyClass(); } 
}
public class MyClass extends MySuperclass {
// (1) INSERT METHOD DECLARATION HERE
}