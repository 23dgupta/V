package com.flightapp.servcie;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.flightapp.exception.AdminNotFound;
import com.flightapp.model.Admin;
import com.flightapp.repository.AdminRepository;


@Service
public class AdminDetailService implements UserDetailsService {

	@Autowired
	private AdminRepository adminRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		Admin admin = adminRepository.findByUsername(username);
		
		if(admin == null) {
			System.out.println("null");
			throw new AdminNotFound( "admin", "adminname", username);
		}
		return new org.springframework.security.core.userdetails.User(admin.getUsername(), new BCryptPasswordEncoder().encode(admin.getPassword()), new ArrayList<>());

	}

}
