package com.flightapp.servcie;

import java.util.List;

import com.flightapp.model.Airline;


public interface AirlineService {

	public Airline add(Airline airline);
	
	List get();
	
	public int blockAirline(long id, boolean block);
}
